//import java.lang.Thread.State;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Breadth-First Search (BFS)
 * 
 * You should fill the search() method of this class.
 */
public class BreadthFirstSearcher extends Searcher {

	/**
	 * Calls the parent class constructor.
	 * 
	 * @see Searcher
	 * @param maze initial maze.
	 */
	public BreadthFirstSearcher(Maze maze) {
		super(maze);
	}

	/**
	 * Main breadth first search algorithm.
	 * 
	 * @return true if the search finds a solution, false otherwise.
	 */
	public boolean search() {
		// FILL THIS METHOD
		// explored list is a 2D Boolean array that indicates if a state associated with a given position in the maze has already been explored.
		boolean[][] explored = new boolean[maze.getNoOfRows()][maze.getNoOfCols()];

		// ...

		// Queue implementing the Frontier list
		LinkedList<State> queue = new LinkedList<State>();
		
		State ini = new State(maze.getPlayerSquare(), null, 0, 0); 
		queue.add(ini);
		
		while (!queue.isEmpty()) {
			State p = queue.pop();
			explored[p.getX()][p.getY()]=true;
			//maxSizeOfFrontier+=1;
			noOfNodesExpanded +=  1;
			//maxDepthSearched += 1;
			if(p.getDepth()>maxDepthSearched) {
				maxDepthSearched=p.getDepth();
			}
			
	        
			if(p.isGoal(maze)) {
				
				while(p.getParent()!=null&&((p.getX()!=ini.getX() || p.getY()!=ini.getY()))) {
					
					cost +=1;
					maze.setOneSquare(new Square(p.getX(),p.getY()), '.');
					p = p.getParent();
					
				}
				//trace back & inc cost
				return true;
			}
			
			//get successors
			
			ArrayList<State> succerors=p.getSuccessors(explored, maze);
				
			for(int i=0; i<succerors.size();i++) {
				boolean helper=true;
				
            	for(int x=0;x<queue.size();x++ ) {
            
            	  if((succerors.get(i).getX()==queue.get(x).getX())&&succerors.get(i).getY()==queue.get(x).getY()){
            		
            			 helper=false;
            			 break;
            	  }
            	}
            	if(helper==true) {
        				queue.add(succerors.get(i)); 
               }
		
				
			}
			if(queue.size()>maxSizeOfFrontier) {
				maxSizeOfFrontier = queue.size();
			}
			
			
			// TODO return true if find a solution
			// TODO maintain the cost, noOfNodesExpanded (a.k.a. noOfNodesExplored),
			// maxDepthSearched, maxSizeOfFrontier during
			// the search
			// TODO update the maze if a solution found

			// use queue.pop() to pop the queue.
			// use queue.add(...) to add elements to queue
			
		}
        return false;
		// TODO return false if no solution
	}
}


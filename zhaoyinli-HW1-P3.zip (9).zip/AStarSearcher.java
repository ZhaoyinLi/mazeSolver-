import java.util.ArrayList;
import java.util.PriorityQueue;
import java.lang.Math;

/**
 * A* algorithm search
 * 
 * You should fill the search() method of this class.
 */
public class AStarSearcher extends Searcher {

	/**
	 * Calls the parent class constructor.
	 * 
	 * @see Searcher
	 * @param maze initial maze.
	 */
	public AStarSearcher(Maze maze) {
		super(maze);
	}

	/**
	 * Main a-star search algorithm.
	 * 
	 * @return true if the search finds a solution, false otherwise.
	 */
	public boolean search() {
		
      
		// FILL THIS METHOD

		// explored list is a Boolean array that indicates if a state associated with a given position in the maze has already been explored. 
		boolean[][] explored = new boolean[maze.getNoOfRows()][maze.getNoOfCols()];
		// ...

		PriorityQueue<StateFValuePair> frontier = new PriorityQueue<StateFValuePair>();
        
		// TODO initialize the root state and add
		// to frontier list
		// ...
	
		int goalX = maze.getGoalSquare().X;
		int goalY = maze.getGoalSquare().Y;
		State initState = new State(maze.getPlayerSquare(), null, 0, 0);
		//StateFValuePair ini = new StateFValuePair(initState, 0.0); 
		int currentX = initState.getX();
		int currentY = initState.getY();
		double hValue = Math.hypot(Math.abs(currentX - goalX), Math.abs(currentY - goalY));
		double fValue = initState.getGValue() + hValue;
		StateFValuePair ini = new StateFValuePair(initState, fValue);
		frontier.add(ini);
		
		
		while (!frontier.isEmpty()) {
			
			if(frontier.size()>maxSizeOfFrontier) {
				maxSizeOfFrontier = frontier.size();
			}
			// TODO return true if a solution has been found
			// TODO maintain the cost, noOfNodesExpanded (a.k.a. noOfNodesExplored),
			// maxDepthSearched, maxSizeOfFrontier during
			// the search
			// TODO update the maze if a solution found

			// use frontier.poll() to extract the minimum stateFValuePair.
			// use frontier.add(...) to add stateFValue pairs
			
			
			StateFValuePair p = frontier.poll();
			State currState = p.getState();
			noOfNodesExpanded +=  1;
			
			if(currState .getDepth()>maxDepthSearched) {
				maxDepthSearched=currState .getDepth();
			}
			
			
			if(currState .isGoal(maze)) {
				
				
				while(currState != null && (currState.getX() != initState.getX()||(currState.getY() != initState.getY() ))) {
					
					maze.setOneSquare(currState.getSquare(), '.');
					currState  = currState .getParent();
					cost +=1;
					
				}
				
				return true;
			}
			
			//get successors
			
			ArrayList<State> succerors=currState .getSuccessors(explored, maze);
			explored[currState .getX()][currState .getY()]=true;
			
			for(int i=0; i<succerors.size();i++) {
				boolean helper=true;
				//State suc = succerors.get(i);
				for (StateFValuePair var : frontier) {
					double hv2=Math.pow((double)Math.sqrt(succerors.get(i).getX()-goalX)+(double)Math.sqrt(succerors.get(i).getY()-goalY),1/2);
            		  double fv2=hv2+succerors.get(i).getGValue();
            	  if((succerors.get(i).getX()==var.getState().getX())&&succerors.get(i).getY()==var.getState().getY()&&fv2>var.getFValue()){ 
            		if(succerors.get(i).getGValue()<var.getState().getGValue()) {
            			frontier.remove(var);
            			double hv=Math.pow((double)Math.sqrt(succerors.get(i).getX()-goalX)+(double)Math.sqrt(succerors.get(i).getY()-goalY),1/2);
               		   double fv=hv+succerors.get(i).getGValue();
               		 StateFValuePair newp = new StateFValuePair(succerors.get(i),fv);
            			frontier.add(newp);
            		}
            		else {
            			helper = false;
            		}
            		break;
            	  }
            	  
              		  
              	  }
              		  
				if(helper) {
			
             		 double hv=Math.pow((double)Math.sqrt(succerors.get(i).getX()-goalX)+(double)Math.sqrt(succerors.get(i).getY()-goalY),1/2);
            		 double fv=hv+succerors.get(i).getGValue();
            		 StateFValuePair newp = new StateFValuePair(succerors.get(i),fv);
           		     frontier.add(newp); 
            	
            	
               }
			}
			
			
			
		
		}

		// TODO return false if no solution
		return false;
	}
	

}
